$(document).ready(function() {
    $(".jquery-background-video-pauseplay").click(function () {
        $('.detail-video').css("display","none");
    });	                   
 });